import criptomoedas

if __name__ == "__main__":
    def inicia():
        return criptomoedas
    inicia()